const form = document.getElementById("task-form");
const taskList = document.getElementById("task-list");

form.addEventListener("submit", (e) => {
  e.preventDefault();
  
  const subject = document.getElementById("subject").value;
  const datetime = document.getElementById("datetime").value;

  const li = document.createElement("li");
  li.textContent = `${subject} - ${new Date(datetime).toLocaleString("pt-BR")}`;
  taskList.appendChild(li);

  form.reset();
});
